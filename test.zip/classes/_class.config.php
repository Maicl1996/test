<?PHP
######################################

######################################
class config{

	public $HostDB = "localhost";
	public $UserDB = "root";
	public $PassDB = "root";
	public $BaseDB = "test";
	public $version = "6";
}
?>
