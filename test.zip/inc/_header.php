<html>
	<head>
<title>Главная | Книги</title>
<link rel="icon" href="data:;base64,=">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" href="/style/main.css?ver=<?=$config->version?>"  type="text/css" media="screen and (min-width: 641px)">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
</head>
<body>